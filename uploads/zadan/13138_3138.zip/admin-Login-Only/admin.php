<?php require_once("adminOnly.php");?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<link rel=stylesheet type="text/css" href="admin-Login-Only.css">

		<TITLE>admin-Login-Only - Administration Page</TITLE>

		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
		<meta name="author" content="Globalissa - Global I.S. S.A.">
		<meta name="generator" content="World Impact">
		<meta name="robots" content="NOINDEX,NOFOLLOW">
		<meta name="revisit-after" content="7 days">
		<meta name="distribution" content="Global">
		<meta name="rating" content="General">
		<meta http-equiv="expires" content="0">
		<meta http-equiv="pragma" content="no-cache">
		<meta http-equiv="cache-control" content="no-cache">
		<meta name="resource-type" content="document">
</HEAD>

<BODY>


<h1>Admin Center</h1>

<p>
A PHP session controls the entrance to this page.
</p>

<p><br></p>


<?php phpinfo();?>


</body>
</html>