<?php
switch ($_GET['n'])
{
case 1:
header('Location: http://c.cpa1.ru/36Zg');
break;
case 2:
header('Location: http://c.cpa1.ru/3ph2');
break;
case 3:
header('Location: http://c.cpa1.ru/36Zh');
break;

}
?>