<html>  
<head>  
    <script src="./libs/jquery.js"></script>  
</head>  
<body>  
    <div id="info">��������...</div>  
    <script>  

        function json_example()  
        {  
            $.getJSON("json1.php", function(data) {  
                s  = "";  
                $.each(data, function(key, val) {   
                    s = s +val   
                });
		if (s=='null')
		{
		$("#info").html("<center>����� ������� ���� ���</center>");  
		}
		else
		{
		$("#info").html("<center>�������� ����� ����� <a href='index.php?link=adm_ocenka&nzakaz="+s+"'>����� "+s+"</a></center>");  
		document.getElementById('player').pause();
		document.getElementById('player').play();
		clearInterval(intervalID);
		}
            });  
        }  

        var intervalID = setInterval(json_example, 5000);  
    </script> 
<audio id='player' controls='controls' autoplay loop>  <source src='http://dl.dropbox.com/u/6001712/aimp/Axwell%20%26%20Sebastian%20Ingrosso%20-%20Together.mp3' />  <source src='http://dl.dropbox.com/u/6001712/aimp/Axwell%20%26%20Sebastian%20Ingrosso%20-%20Together.ogg' /> </audio>
</body>  
</body>
</html>  